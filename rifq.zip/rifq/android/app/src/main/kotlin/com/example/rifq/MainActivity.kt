package com.example.rifq

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
