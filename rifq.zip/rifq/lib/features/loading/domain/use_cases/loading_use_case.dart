// import 'package:injectable/injectable.dart';
// import 'package:multiple_result/multiple_result.dart';
// import '../../../../core/shared/shared_auth/entities/auth_entity.dart';
// import '../repositories/loading_repo_domain.dart';

// @singleton
// class LoadingUseCase {
//   final LoadingRepoDomain loadingRepoDate;

//   LoadingUseCase({required this.loadingRepoDate});

//   Future<Result<AuthEntity, Object>> checkAuth() async {
//     return await loadingRepoDate.checkAuth();
//   }


// }
