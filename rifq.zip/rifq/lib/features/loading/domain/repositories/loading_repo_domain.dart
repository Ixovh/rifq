// import 'package:multiple_result/multiple_result.dart';
// import '../../../../core/shared/shared_auth/entities/auth_entity.dart';

// abstract class LoadingRepoDomain {
//   Future<Result<AuthEntity, Object>> checkAuth();
// }
