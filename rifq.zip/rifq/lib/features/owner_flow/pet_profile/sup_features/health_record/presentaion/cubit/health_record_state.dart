part of 'health_record_cubit.dart';

@immutable
sealed class HealthRecordState {}

final class HealthRecordInitial extends HealthRecordState {}
